# 🌀 Vortex Photo Organizer

A lightweight, production-quality personal photo organizer that automatically sorts your photographs into a clean **Year → Month** folder hierarchy based on their original capture date. Never modifies the original files.

## Table of Contents

- [Overview](#overview)
- [Key Features](#key-features)
- [Architecture](#architecture)
- [Folder Structure](#folder-structure)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Docker Deployment](#docker-deployment)
- [Local Development](#local-development)
- [API Documentation](#api-documentation)
- [Configuration](#configuration)
- [How It Works](#how-it-works)
- [Duplicate Detection](#duplicate-detection)
- [Logging](#logging)
- [Build Instructions](#build-instructions)
- [Design Decisions](#design-decisions)
- [Troubleshooting](#troubleshooting)
- [Future Enhancements](#future-enhancements)

## Overview

Vortex Photo Organizer is a minimal, fast web application designed for personal use. It helps you organize photo collections by automatically creating a structured folder hierarchy:

```
PhotoLibrary/
├── 2024/
│   ├── January/
│   ├── February/
│   └── March/
├── 2025/
│   ├── January/
│   └── February/
└── 2026/
    └── April/
```

**Core Philosophy:**
- **Copies, never moves** - Original files stay untouched
- **Smart metadata reading** - Extracts EXIF dates, falls back to file creation/modified dates
- **Zero data loss** - Duplicate detection prevents overwriting existing files
- **Comprehensive logging** - Every action is logged for audit trails
- **Production-ready** - Error handling, validation, and graceful degradation

## Key Features

✅ **Safe Organization** - Files are copied, never moved or deleted
✅ **Smart Date Detection** - EXIF > File Created > Last Modified priority
✅ **Duplicate Detection** - Prevents overwriting existing files
✅ **Dry Run Mode** - Preview changes without copying
✅ **Real-time Progress** - Live status updates during organization
✅ **Export Reports** - CSV exports for duplicates and file manifests
✅ **Comprehensive Logs** - Detailed logs of all operations
✅ **Multi-format Support** - JPG, JPEG, PNG, HEIC, TIFF, WEBP
✅ **Cross-platform** - Works on macOS, Linux, Windows (Docker)
✅ **Minimal Dependencies** - Fast, lightweight, easy to maintain

## Architecture

The application uses a **client-server architecture** with clean separation of concerns:

```
Frontend (React + Vite)
    ↓ (REST API)
Backend (Node.js + Express)
    ↓
File System Operations
    ↓
Logging & Reports
```

### Technology Stack

**Frontend:**
- React 18 with TypeScript
- Vite (ultra-fast bundler)
- Modern CSS with CSS variables
- Responsive, accessible UI

**Backend:**
- Node.js 20+ with Express
- TypeScript for type safety
- Modular service architecture
- Comprehensive error handling

**Infrastructure:**
- Docker for containerization
- Docker Compose for orchestration
- Single port (4001) for all communication
- ~100MB memory footprint

## Folder Structure

```
vortex-photo-organizer/
├── backend/
│   ├── src/
│   │   ├── index.ts                 # Express server & routes
│   │   ├── types.ts                 # TypeScript definitions
│   │   ├── services/
│   │   │   └── organizerService.ts  # Business logic
│   │   └── utils/
│   │       ├── logger.ts            # File & console logging
│   │       ├── metadata.ts          # Photo date extraction
│   │       └── fileOps.ts           # File operations
│   ├── package.json
│   └── tsconfig.json
├── frontend/
│   ├── src/
│   │   ├── main.tsx                 # Entry point
│   │   ├── App.tsx                  # Main app component
│   │   ├── components/              # UI components
│   │   ├── services/                # API client
│   │   ├── types/                   # TypeScript types
│   │   └── styles/                  # CSS
│   ├── index.html                   # HTML entry
│   ├── package.json
│   ├── tsconfig.json
│   └── vite.config.ts
├── logs/                            # Application logs directory
├── public/                          # Static assets
├── Dockerfile                       # Container definition
├── docker-compose.yml               # Orchestration
├── package.json                     # Root package config
└── README.md                        # This file
```

## Installation

### Prerequisites

- **Node.js** 20+ (for local development)
- **Docker & Docker Compose** (for containerized deployment)
- **Git** (to clone the repository)

### Option 1: Local Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/vortex-photo-organizer.git
cd vortex-photo-organizer

# Install all dependencies
npm install --workspaces

# Build both frontend and backend
npm run build

# Start the application
npm start
```

Visit `http://localhost:4001` in your browser.

### Option 2: Docker Installation (Recommended)

```bash
# Build the Docker image
docker build -t vortex-photo-organizer:latest .

# Run with Docker
docker run -p 4001:4001 -v $(pwd)/logs:/app/logs vortex-photo-organizer:latest
```

### Option 3: Docker Compose (Easiest)

```bash
# Start everything with one command
docker-compose up -d

# View logs
docker-compose logs -f vortex

# Stop the application
docker-compose down
```

Visit `http://localhost:4001`

## Quick Start

1. **Open the Web UI** at `http://localhost:4001`

2. **Enter directories:**
   - **Source Directory:** Path containing your photos (e.g., `/Users/me/Pictures/Camera`)
   - **Destination Directory:** Where organized photos will be copied (e.g., `/Users/me/PhotoLibrary`)

3. **Optional: Enable Dry Run** - Preview changes without copying files

4. **Click "Organize"** - Watch real-time progress

5. **Review Results** - Export duplicate report and file manifest if needed

## Docker Deployment

### Building the Docker Image

```bash
docker build -t vortex-photo-organizer:latest .
```

### Running with Docker

```bash
# Basic run (logs stored in container)
docker run -p 4001:4001 vortex-photo-organizer:latest

# With persistent logs
docker run -p 4001:4001 -v vortex-logs:/app/logs vortex-photo-organizer:latest

# With photo directory mounts (macOS/Linux)
docker run -p 4001:4001 \
  -v /Volumes/photos:/photos:ro \
  -v /Volumes/organized:/organized \
  -v vortex-logs:/app/logs \
  vortex-photo-organizer:latest
```

### Using Docker Compose

```bash
# Start all services
docker-compose up -d

# View real-time logs
docker-compose logs -f vortex

# Stop services
docker-compose down

# Remove everything (including volumes)
docker-compose down -v
```

### Volume Mounts

To access directories on your host system from Docker:

```yaml
volumes:
  - /path/to/photos:/photos:ro        # Read-only source photos
  - /path/to/organized:/organized      # Destination for organized photos
  - ./logs:/app/logs                   # Persistent logs
```

## Local Development

### Setup

```bash
# Install dependencies
npm install --workspaces

# Start backend development server
npm run dev:backend

# In another terminal, start frontend dev server
npm run dev:frontend
```

Backend runs on `http://localhost:4001`
Frontend dev server on `http://localhost:5173` (with proxy to backend)

### Development Workflow

```bash
# Watch mode (auto-recompile on changes)
npm run dev

# Build for production
npm run build

# Run production build
npm start
```

### TypeScript Compilation

```bash
# Type-check everything
npx tsc --noEmit

# Build both packages
npm run build:backend && npm run build:frontend
```

## API Documentation

All endpoints are RESTful and accept/return JSON.

### Base URL
```
http://localhost:4001/api
```

### Endpoints

#### POST /scan
Scan source directory for photos (dry run first).

**Request:**
```json
{
  "sourceDir": "/path/to/photos",
  "dryRun": true
}
```

**Response:**
```json
{
  "message": "Scan completed",
  "photoCount": 1234,
  "state": { ... }
}
```

#### POST /organize
Start the organization process.

**Request:**
```json
{
  "sourceDir": "/path/to/photos",
  "destDir": "/path/to/organized",
  "dryRun": false
}
```

**Response:**
```json
{
  "message": "Organization completed",
  "result": {
    "totalPhotos": 1234,
    "yearsCreated": ["2024", "2025", "2026"],
    "monthsCreated": 12,
    "filesCopied": 1200,
    "duplicateNamesFound": 34,
    "errors": [],
    "skippedFiles": 0
  },
  "state": { ... }
}
```

#### GET /progress
Get current organization progress (poll this for live updates).

**Response:**
```json
{
  "status": "organizing",
  "progress": 45,
  "currentFile": "IMG_1234.JPG",
  "currentYear": "2025",
  "currentMonth": "February",
  "filesCopied": 540,
  "filesSkipped": 12,
  "duplicatesFound": 8,
  "elapsedTime": 3600,
  "estimatedTimeRemaining": 4400,
  "totalFiles": 1200
}
```

#### GET /logs
Get recent log entries.

**Query Parameters:**
- `lines` (optional, default: 100) - Number of log lines to return

**Response:**
```json
{
  "logs": "[2024-01-15T10:30:45.123Z] [INFO] Organization started..."
}
```

#### GET /duplicates
Get duplicate detection report.

**Response:**
```json
{
  "count": 34,
  "duplicates": [
    {
      "filename": "IMG_1234.JPG",
      "destination": "2025/February/IMG_1234.JPG",
      "sourceFile": "/path/to/photos/IMG_1234.JPG",
      "sourceDir": "/path/to/photos"
    }
  ]
}
```

#### GET /manifest
Get complete manifest of all processed files.

**Response:**
```json
{
  "count": 1234,
  "manifest": [
    {
      "sourcePath": "/path/to/photos/IMG_0001.JPG",
      "destinationPath": "2025/February/IMG_0001.JPG",
      "captureDate": "2025-02-14T15:30:00Z",
      "status": "copied"
    }
  ]
}
```

#### POST /logs/clear
Clear all log entries.

**Response:**
```json
{
  "message": "Logs cleared"
}
```

#### GET /export/duplicates
Export duplicate report as CSV.

**Response:** CSV file download
```
Filename,Destination,Source File,Source Directory
"IMG_1234.JPG","2025/February/IMG_1234.JPG","/path/to/photos/IMG_1234.JPG","/path/to/photos"
```

#### GET /export/manifest
Export file manifest as CSV.

**Response:** CSV file download

## Configuration

### Environment Variables

```bash
# Port to run the server on (default: 4001)
PORT=4001

# Node environment
NODE_ENV=production
```

### Runtime Configuration

Configuration is done through the UI:
- **Source Directory** - Path to your photo source
- **Destination Directory** - Path where organized photos are copied
- **Dry Run Mode** - Preview before committing

## How It Works

### Photo Date Extraction Priority

The application uses this priority order to determine a photo's capture date:

1. **EXIF DateTime** (most accurate)
   - Embedded metadata from camera
   - Timestamp when photo was taken
   - Most reliable source

2. **File Creation Date** (fallback 1)
   - OS filesystem metadata
   - When file was first created/imported
   - Reliable if EXIF is missing

3. **File Modified Date** (fallback 2)
   - Last modification timestamp
   - Used as last resort
   - Ensures every file can be organized

### Organization Process

```
1. Scan Source Directory
   ↓
2. For Each Photo:
   a) Extract metadata (date)
   b) Determine Year/Month folders
   c) Check if destination exists
   d) Copy file (if not duplicate)
   e) Log result
   ↓
3. Generate Reports
   - Duplicate report
   - File manifest
   - Error summary
   ↓
4. Export & Archive
   - CSV export available
   - Full audit trail in logs
```

### File Copying Strategy

- **Never moves** original files - They remain in source directory
- **Never deletes** anything - Complete safety
- **Incremental processing** - Processes one file at a time to avoid memory bloat
- **Resume-friendly** - Can be interrupted without data loss
- **Duplicate-safe** - Skips if destination file already exists

## Duplicate Detection

### What Counts as a Duplicate?

A file is considered a duplicate if:
1. **Same filename** exists in the destination year/month folder
2. **Destination file already exists** (prevents overwriting)

### Duplicate Report

After organization, generate a duplicate report showing:
- Filename
- Destination path
- Source file path
- Source directory

**Example:**
```
2025/February/IMG_1234.JPG exists
  ├─ Destination: /organized/2025/February/IMG_1234.JPG
  ├─ Source File: /photos/vacation/IMG_1234.JPG
  └─ Source Dir: /photos/vacation
```

### Why Files Are Skipped

- **Filename duplicate** - File with same name already exists at destination
- **Permission denied** - Source or destination permission issues
- **Invalid metadata** - Could not extract valid capture date
- **Corrupted file** - File is not readable

## Logging

### Log File Location

```
logs/organizer.log
```

### Log Format

Each log entry includes:
```
[ISO-8601 Timestamp] [LOG_LEVEL] Message | Data
```

**Example:**
```
[2024-01-15T10:30:45.123Z] [INFO] Organization started | {"sourceDir":"/photos","destDir":"/organized","dryRun":false}
[2024-01-15T10:30:46.456Z] [DEBUG] File copied | {"sourcePath":"/photos/IMG_0001.JPG","destPath":"2025/February/IMG_0001.JPG"}
[2024-01-15T10:31:12.789Z] [WARN] File skipped | {"filePath":"/photos/IMG_0002.JPG","reason":"Duplicate"}
[2024-01-15T10:32:00.000Z] [INFO] Organization completed | {"filesCopied":1200,"errors":0}
```

### Log Levels

- **DEBUG** - Detailed information (file operations)
- **INFO** - General information (start/end, counts)
- **WARN** - Warnings (skipped files, permission issues)
- **ERROR** - Errors (failed operations)

### Viewing Logs

**Via UI:** Click "Show Logs" to view in real-time

**Via API:**
```bash
curl http://localhost:4001/api/logs?lines=100
```

**Via Command Line:**
```bash
tail -f logs/organizer.log
```

## Build Instructions

### Building from Source

```bash
# Install dependencies
npm install --workspaces

# Build backend
npm run build:backend

# Build frontend
npm run build:frontend

# Build Docker image
npm run docker:build
```

### Build Output

```
backend/dist/       # Compiled backend JavaScript
frontend/dist/      # Compiled frontend assets
```

### Production Build

```bash
# Full production build
npm run build

# Verify production build
npm start
```

## Design Decisions

### Why TypeScript?

- Strong type safety prevents runtime errors
- Better IDE support and autocomplete
- Self-documenting code
- Easier refactoring

### Why React?

- Simple component-based UI
- Reactive state management
- Large ecosystem and community support
- Easy to extend

### Why Vite?

- Ultra-fast development server (milliseconds)
- Fast production builds
- Modern ES modules support
- Zero-config setup

### Why Express.js?

- Minimal, lightweight framework
- Excellent for REST APIs
- Huge community and middleware ecosystem
- Battle-tested in production

### Why Separate Frontend/Backend?

- Clear separation of concerns
- Backend can be used headlessly
- Frontend can be deployed independently
- Easy to scale and maintain

### Why Copy Instead of Move?

- **Safety first** - Never destroys original files
- **Non-destructive** - Maintains original directory structure
- **Reversible** - Can delete destination without loss
- **Audit trail** - Can verify copies match originals

### Why EXIF-First?

- **Most accurate** - Reflects actual capture time
- **Camera metadata** - Reliable source of truth
- **Handles time zones** - EXIF includes timezone info
- **Works with imports** - Valid even if file was modified

## Troubleshooting

### Application Won't Start

**Docker error: Cannot connect to port 4001**
```bash
# Check if port is in use
lsof -i :4001

# Kill existing process
kill -9 <PID>

# Try a different port
docker run -p 4002:4001 vortex-photo-organizer:latest
```

### No Photos Found

**Problem:** Scan returns 0 photos

**Solutions:**
1. Check source directory path is correct
2. Verify photos are in subdirectories (not just root)
3. Check file permissions (`chmod +r` on photo files)
4. Verify file format is supported (jpg, png, heic, etc.)

**Test path:**
```bash
ls -la /path/to/photos/
# Check for .jpg, .png, .heic files
find /path/to/photos -type f \( -name "*.jpg" -o -name "*.png" \)
```

### Permissions Denied

**Problem:** "Permission denied" errors during organization

**Solutions:**
```bash
# Make source photos readable
chmod -R +r /path/to/photos

# Make destination writable
chmod -R +w /path/to/organized

# Run with elevated privileges (use with caution)
sudo docker run -p 4001:4001 vortex-photo-organizer:latest
```

### Docker Volume Issues (macOS/Windows)

**Problem:** Docker can't access host directories

**Solutions:**
1. **Docker Desktop:** Go to Settings > Resources > File Sharing
2. **Add your photo directories** to the shared paths
3. **Use absolute paths** when mounting volumes
4. **Restart Docker Desktop**

```bash
docker-compose down
docker-compose up -d
```

### Memory Issues with Large Collections

**Problem:** Application slows down with 50,000+ photos

**Solutions:**
1. Process in batches (organize subdirectories separately)
2. Increase Docker memory allocation: `--memory 2g`
3. Check system RAM availability
4. Monitor logs for specific error

### Logs Not Persisting

**Problem:** Logs disappear after container restart

**Solution:** Mount log volume:
```bash
docker run -p 4001:4001 -v vortex-logs:/app/logs vortex-photo-organizer:latest
```

Or with docker-compose:
```yaml
volumes:
  - ./logs:/app/logs
```

### Duplicate Detection Not Working

**Problem:** Duplicates not being detected

**Causes:**
1. Files have different names (same photo, different name)
2. Destination directory doesn't exist yet
3. Filenames differ by case (IMG_001.jpg vs img_001.jpg)

**Limitation:** Currently detects filename duplicates only. Content-based detection (SHA-256 hash) is a future enhancement.

## Future Enhancements

### Near-Term (v1.1)

- [ ] **Content-based Duplicate Detection** - SHA-256 hash comparison
- [ ] **Manifest File** - CSV/JSON audit trail of all processed files
- [ ] **Resume Support** - Continue interrupted organization jobs
- [ ] **Cross-platform Directory Picker** - Native file dialogs instead of text input
- [ ] **Video Support** - Organize video files (MP4, MOV, etc.)

### Medium-Term (v1.2)

- [ ] **Thumbnail Generation** - Fast preview thumbnails
- [ ] **Timeline View** - Visual calendar of photos by date
- [ ] **Search & Filter** - Find photos by date range, name
- [ ] **EXIF Metadata Viewer** - Display camera settings, location data
- [ ] **RAW Image Support** - CR2, NEF, ARW formats

### Long-Term (v2.0)

- [ ] **Face Recognition** - Group photos by person
- [ ] **AI Tags** - Auto-generate descriptive tags
- [ ] **Scheduled Organization** - Automatic weekly/monthly organization
- [ ] **Folder Watching** - Watch directories for new photos
- [ ] **Dark Mode** - UI theme support
- [ ] **Web Dashboard** - Statistics and insights
- [ ] **Cloud Storage** - S3, Google Drive integration
- [ ] **Photo Editing** - Basic crop, rotate, filter
- [ ] **Undo Support** - Reverse last organization operation
- [ ] **Multi-user Support** - Team/family organization

## License

MIT License - See LICENSE file for details

## Contributing

Contributions welcome! Areas for improvement:
- Additional photo format support
- Better EXIF extraction
- Performance optimizations
- UI/UX improvements
- Better error messages
- Documentation

## Support

For issues, feature requests, or questions:

1. Check the Troubleshooting section
2. Review logs in `logs/organizer.log`
3. Test with dry-run mode first
4. Open an issue on GitHub

## Changelog

### v1.0.0 (Initial Release)
- Core photo organization functionality
- EXIF metadata extraction
- Duplicate detection (filename-based)
- Real-time progress tracking
- Comprehensive logging
- Docker support
- RESTful API
- Web UI with React

---

**Built with ❤️ for photo enthusiasts who value safety, simplicity, and control.**
