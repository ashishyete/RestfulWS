export interface OrganizationState {
  status: 'idle' | 'scanning' | 'organizing' | 'completed' | 'error';
  sourceDir: string;
  destDir: string;
  progress: number;
  currentFile: string;
  currentYear: string;
  currentMonth: string;
  filesCopied: number;
  filesSkipped: number;
  duplicatesFound: number;
  errors: string[];
  startTime: number | null;
  estimatedTimeRemaining: number | null;
  elapsedTime: number;
  totalFiles: number;
  dryRun: boolean;
}

export interface PhotoMetadata {
  filePath: string;
  filename: string;
  captureDate: Date;
  source: 'exif' | 'created' | 'modified';
  year: string;
  month: string;
  monthName: string;
}

export interface DuplicateEntry {
  filename: string;
  destination: string;
  sourceFile: string;
  sourceDir: string;
}

export interface OrganizationResult {
  totalPhotos: number;
  yearsCreated: string[];
  monthsCreated: number;
  filesCopied: number;
  duplicateNamesFound: number;
  errors: string[];
  skippedFiles: number;
  duplicateReport: DuplicateEntry[];
  manifest: ManifestEntry[];
}

export interface ManifestEntry {
  sourcePath: string;
  destinationPath: string;
  captureDate: string;
  status: 'copied' | 'skipped' | 'error';
  duplicateInfo?: string;
  error?: string;
}

export type PhotoFormat = 'jpg' | 'jpeg' | 'png' | 'heic' | 'tiff' | 'webp';
