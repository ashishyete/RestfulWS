import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const LOG_DIR = path.join(__dirname, '../../logs');
const LOG_FILE = path.join(LOG_DIR, 'organizer.log');

export enum LogLevel {
  DEBUG = 'DEBUG',
  INFO = 'INFO',
  WARN = 'WARN',
  ERROR = 'ERROR'
}

export class Logger {
  private static instance: Logger;
  private initialized = false;

  private constructor() {}

  static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  async initialize(): Promise<void> {
    if (this.initialized) return;
    try {
      await fs.mkdir(LOG_DIR, { recursive: true });
      this.initialized = true;
    } catch (error) {
      console.error('Failed to initialize logger:', error);
    }
  }

  private formatMessage(level: LogLevel, message: string, data?: unknown): string {
    const timestamp = new Date().toISOString();
    const dataStr = data ? ` | ${JSON.stringify(data)}` : '';
    return `[${timestamp}] [${level}] ${message}${dataStr}`;
  }

  async log(level: LogLevel, message: string, data?: unknown): Promise<void> {
    const formatted = this.formatMessage(level, message, data);
    console.log(formatted);

    try {
      await fs.appendFile(LOG_FILE, formatted + '\n');
    } catch (error) {
      console.error('Failed to write to log file:', error);
    }
  }

  debug(message: string, data?: unknown): Promise<void> {
    return this.log(LogLevel.DEBUG, message, data);
  }

  info(message: string, data?: unknown): Promise<void> {
    return this.log(LogLevel.INFO, message, data);
  }

  warn(message: string, data?: unknown): Promise<void> {
    return this.log(LogLevel.WARN, message, data);
  }

  error(message: string, data?: unknown): Promise<void> {
    return this.log(LogLevel.ERROR, message, data);
  }

  async getLogs(lines: number = 100): Promise<string> {
    try {
      const content = await fs.readFile(LOG_FILE, 'utf-8');
      return content.split('\n').slice(-lines).join('\n');
    } catch (error) {
      return 'No logs available';
    }
  }

  async clearLogs(): Promise<void> {
    try {
      await fs.writeFile(LOG_FILE, '');
    } catch (error) {
      console.error('Failed to clear logs:', error);
    }
  }
}

export const logger = Logger.getInstance();
