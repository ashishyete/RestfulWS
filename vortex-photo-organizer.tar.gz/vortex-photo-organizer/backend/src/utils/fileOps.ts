import fs from 'fs/promises';
import path from 'path';
import { logger } from './logger.js';

/**
 * Check if file exists
 */
export async function fileExists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

/**
 * Check if directory exists
 */
export async function dirExists(dirPath: string): Promise<boolean> {
  try {
    const stats = await fs.stat(dirPath);
    return stats.isDirectory();
  } catch {
    return false;
  }
}

/**
 * Create directory recursively
 */
export async function ensureDir(dirPath: string): Promise<void> {
  try {
    await fs.mkdir(dirPath, { recursive: true });
  } catch (error) {
    logger.error('Failed to create directory', { dirPath, error: String(error) });
    throw error;
  }
}

/**
 * Copy file from source to destination
 * Returns true if copied, false if skipped
 */
export async function copyFile(
  sourcePath: string,
  destPath: string,
  dryRun: boolean = false
): Promise<{ success: boolean; reason?: string }> {
  try {
    // Check if destination file already exists
    const destExists = await fileExists(destPath);
    if (destExists) {
      return { success: false, reason: 'File already exists at destination' };
    }

    if (dryRun) {
      return { success: true, reason: 'Dry run - would be copied' };
    }

    // Ensure destination directory exists
    const destDir = path.dirname(destPath);
    await ensureDir(destDir);

    // Copy file
    await fs.copyFile(sourcePath, destPath);
    logger.debug('File copied', { sourcePath, destPath });
    return { success: true };
  } catch (error) {
    const errorMsg = String(error);
    logger.error('Failed to copy file', { sourcePath, destPath, error: errorMsg });
    return { success: false, reason: errorMsg };
  }
}

/**
 * Get file size in bytes
 */
export async function getFileSize(filePath: string): Promise<number> {
  try {
    const stats = await fs.stat(filePath);
    return stats.size;
  } catch (error) {
    logger.warn('Failed to get file size', { filePath });
    return 0;
  }
}

/**
 * Compare two files byte-by-byte
 */
export async function areFileIdentical(
  file1: string,
  file2: string
): Promise<boolean> {
  try {
    const size1 = await getFileSize(file1);
    const size2 = await getFileSize(file2);

    if (size1 !== size2) {
      return false;
    }

    const content1 = await fs.readFile(file1);
    const content2 = await fs.readFile(file2);

    return Buffer.compare(content1, content2) === 0;
  } catch (error) {
    logger.warn('Failed to compare files', { file1, file2 });
    return false;
  }
}

/**
 * List all files in a directory
 */
export async function listFiles(dirPath: string): Promise<string[]> {
  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    return entries
      .filter(entry => entry.isFile())
      .map(entry => entry.name);
  } catch (error) {
    logger.warn('Failed to list files', { dirPath });
    return [];
  }
}

/**
 * List all directories in a path
 */
export async function listDirs(dirPath: string): Promise<string[]> {
  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    return entries
      .filter(entry => entry.isDirectory())
      .map(entry => entry.name);
  } catch (error) {
    logger.warn('Failed to list directories', { dirPath });
    return [];
  }
}

/**
 * Get directory structure as nested object
 */
export async function getDirectoryStructure(
  dirPath: string,
  maxDepth: number = 3,
  currentDepth: number = 0
): Promise<Record<string, unknown>> {
  if (currentDepth >= maxDepth) {
    return {};
  }

  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    const structure: Record<string, unknown> = {};

    for (const entry of entries) {
      if (entry.isDirectory()) {
        structure[entry.name] = await getDirectoryStructure(
          path.join(dirPath, entry.name),
          maxDepth,
          currentDepth + 1
        );
      } else {
        structure[entry.name] = { type: 'file' };
      }
    }

    return structure;
  } catch (error) {
    logger.warn('Failed to get directory structure', { dirPath });
    return {};
  }
}
