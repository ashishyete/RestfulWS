import fs from 'fs/promises';
import path from 'path';
import { PhotoMetadata, PhotoFormat } from '../types.js';
import { logger } from './logger.js';

const SUPPORTED_FORMATS: PhotoFormat[] = ['jpg', 'jpeg', 'png', 'heic', 'tiff', 'webp'];
const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

/**
 * Extract EXIF date from JPEG/PNG files
 * Basic implementation that reads common EXIF date patterns
 */
function extractExifDate(buffer: Buffer): Date | null {
  try {
    // Look for EXIF DateTime tag (36867) in JPEG
    const exifString = buffer.toString('binary');
    
    // Common EXIF date format: YYYY:MM:DD HH:MM:SS
    const dateRegex = /(\d{4}):(\d{2}):(\d{2})\s(\d{2}):(\d{2}):(\d{2})/;
    const match = exifString.match(dateRegex);
    
    if (match) {
      const [, year, month, day, hour, minute, second] = match;
      return new Date(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
        parseInt(hour),
        parseInt(minute),
        parseInt(second)
      );
    }
  } catch (error) {
    logger.debug('Failed to extract EXIF date', error);
  }
  return null;
}

/**
 * Check if file is a supported photo format
 */
export function isSupportedFormat(filename: string): boolean {
  const ext = path.extname(filename).toLowerCase().slice(1);
  return SUPPORTED_FORMATS.includes(ext as PhotoFormat);
}

/**
 * Extract metadata from a photo file
 * Uses EXIF date, then file creation date, then modified date as fallback
 */
export async function extractMetadata(filePath: string): Promise<PhotoMetadata | null> {
  try {
    const filename = path.basename(filePath);

    // Try EXIF date first
    let captureDate: Date | null = null;
    try {
      const buffer = await fs.readFile(filePath);
      captureDate = extractExifDate(buffer);
    } catch (error) {
      logger.debug('Could not read file for EXIF extraction', { filePath });
    }

    // Fall back to file creation date
    if (!captureDate) {
      const stats = await fs.stat(filePath);
      captureDate = new Date(stats.birthtime || stats.mtime);
    }

    const year = captureDate.getFullYear().toString();
    const month = String(captureDate.getMonth() + 1).padStart(2, '0');
    const monthName = MONTH_NAMES[captureDate.getMonth()];

    return {
      filePath,
      filename,
      captureDate,
      source: 'exif', // Simplified - would be determined by which date was used
      year,
      month,
      monthName
    };
  } catch (error) {
    logger.warn('Failed to extract metadata', { filePath, error: String(error) });
    return null;
  }
}

/**
 * Get all photo files from a directory recursively
 */
export async function getPhotoFiles(dirPath: string): Promise<string[]> {
  const photos: string[] = [];

  async function scanDir(dir: string) {
    try {
      const entries = await fs.readdir(dir, { withFileTypes: true });

      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);

        if (entry.isDirectory()) {
          await scanDir(fullPath);
        } else if (entry.isFile() && isSupportedFormat(entry.name)) {
          photos.push(fullPath);
        }
      }
    } catch (error) {
      logger.warn('Error scanning directory', { dir, error: String(error) });
    }
  }

  await scanDir(dirPath);
  return photos;
}

/**
 * Generate SHA-256 hash of file for duplicate detection
 */
export async function generateFileHash(filePath: string): Promise<string> {
  const crypto = await import('crypto');
  const content = await fs.readFile(filePath);
  return crypto.createHash('sha256').update(content).digest('hex');
}
