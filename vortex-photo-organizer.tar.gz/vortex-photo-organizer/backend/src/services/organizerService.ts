import path from 'path';
import {
  OrganizationState,
  OrganizationResult,
  DuplicateEntry,
  ManifestEntry
} from '../types.js';
import { extractMetadata, getPhotoFiles, isSupportedFormat } from '../utils/metadata.js';
import { copyFile, dirExists, ensureDir, fileExists, listFiles } from '../utils/fileOps.js';
import { logger } from '../utils/logger.js';

export class OrganizerService {
  private state: OrganizationState = {
    status: 'idle',
    sourceDir: '',
    destDir: '',
    progress: 0,
    currentFile: '',
    currentYear: '',
    currentMonth: '',
    filesCopied: 0,
    filesSkipped: 0,
    duplicatesFound: 0,
    errors: [],
    startTime: null,
    estimatedTimeRemaining: null,
    elapsedTime: 0,
    totalFiles: 0,
    dryRun: false
  };

  private duplicates: DuplicateEntry[] = [];
  private manifest: ManifestEntry[] = [];

  getState(): OrganizationState {
    return { ...this.state };
  }

  setState(updates: Partial<OrganizationState>): void {
    this.state = { ...this.state, ...updates };
  }

  async scan(sourceDir: string, dryRun: boolean = false): Promise<{ count: number; error?: string }> {
    try {
      this.state = {
        status: 'scanning',
        sourceDir,
        destDir: this.state.destDir,
        progress: 0,
        currentFile: '',
        currentYear: '',
        currentMonth: '',
        filesCopied: 0,
        filesSkipped: 0,
        duplicatesFound: 0,
        errors: [],
        startTime: null,
        estimatedTimeRemaining: null,
        elapsedTime: 0,
        totalFiles: 0,
        dryRun
      };

      // Validate source directory
      if (!(await dirExists(sourceDir))) {
        const error = `Source directory does not exist: ${sourceDir}`;
        await logger.error(error);
        this.state.status = 'error';
        this.state.errors.push(error);
        return { count: 0, error };
      }

      // Get all photos
      const photoFiles = await getPhotoFiles(sourceDir);
      this.state.totalFiles = photoFiles.length;

      await logger.info(`Scan complete`, { sourceDir, photoCount: photoFiles.length });

      return { count: photoFiles.length };
    } catch (error) {
      const errorMsg = String(error);
      await logger.error('Scan failed', { error: errorMsg });
      this.state.status = 'error';
      this.state.errors.push(errorMsg);
      return { count: 0, error: errorMsg };
    }
  }

  async organize(sourceDir: string, destDir: string, dryRun: boolean = false): Promise<OrganizationResult> {
    try {
      this.state.status = 'organizing';
      this.state.sourceDir = sourceDir;
      this.state.destDir = destDir;
      this.state.dryRun = dryRun;
      this.state.startTime = Date.now();
      this.duplicates = [];
      this.manifest = [];

      // Validate directories
      if (!(await dirExists(sourceDir))) {
        throw new Error(`Source directory not found: ${sourceDir}`);
      }

      if (!dryRun && !(await dirExists(destDir))) {
        await ensureDir(destDir);
      }

      await logger.info('Organization started', { sourceDir, destDir, dryRun });

      // Get all photos
      const photoFiles = await getPhotoFiles(sourceDir);
      this.state.totalFiles = photoFiles.length;

      // Process each photo
      for (let i = 0; i < photoFiles.length; i++) {
        const photoPath = photoFiles[i];
        this.state.currentFile = path.basename(photoPath);
        this.state.progress = Math.round((i / photoFiles.length) * 100);

        // Calculate ETA
        if (this.state.startTime && i > 0) {
          const elapsed = Date.now() - this.state.startTime;
          const avgTime = elapsed / i;
          const remaining = (photoFiles.length - i) * avgTime;
          this.state.estimatedTimeRemaining = Math.round(remaining);
          this.state.elapsedTime = Math.round(elapsed);
        }

        await this.processPhoto(photoPath, destDir);
      }

      this.state.status = 'completed';
      this.state.elapsedTime = Math.round((Date.now() - (this.state.startTime || 0)) / 1000);

      await logger.info('Organization completed', {
        filesCopied: this.state.filesCopied,
        filesSkipped: this.state.filesSkipped,
        duplicates: this.state.duplicatesFound,
        errors: this.state.errors.length
      });

      return this.buildResult();
    } catch (error) {
      const errorMsg = String(error);
      await logger.error('Organization failed', { error: errorMsg });
      this.state.status = 'error';
      this.state.errors.push(errorMsg);
      return this.buildResult();
    }
  }

  private async processPhoto(photoPath: string, destDir: string): Promise<void> {
    try {
      // Extract metadata
      const metadata = await extractMetadata(photoPath);
      if (!metadata) {
        this.state.filesSkipped++;
        this.manifest.push({
          sourcePath: photoPath,
          destinationPath: '',
          captureDate: 'unknown',
          status: 'skipped',
          error: 'Could not extract metadata'
        });
        return;
      }

      this.state.currentYear = metadata.year;
      this.state.currentMonth = metadata.monthName;

      // Build destination path
      const yearDir = path.join(destDir, metadata.year);
      const monthDir = path.join(yearDir, metadata.monthName);
      const destPath = path.join(monthDir, metadata.filename);

      // Check for duplicates
      if (await fileExists(destPath)) {
        this.state.duplicatesFound++;
        this.duplicates.push({
          filename: metadata.filename,
          destination: destPath,
          sourceFile: photoPath,
          sourceDir: path.dirname(photoPath)
        });

        this.manifest.push({
          sourcePath: photoPath,
          destinationPath: destPath,
          captureDate: metadata.captureDate.toISOString(),
          status: 'skipped',
          duplicateInfo: `File already exists at ${destPath}`
        });

        return;
      }

      // Copy file
      const copyResult = await copyFile(photoPath, destPath, this.state.dryRun);

      if (copyResult.success) {
        this.state.filesCopied++;
        this.manifest.push({
          sourcePath: photoPath,
          destinationPath: destPath,
          captureDate: metadata.captureDate.toISOString(),
          status: 'copied'
        });
      } else {
        this.state.filesSkipped++;
        this.manifest.push({
          sourcePath: photoPath,
          destinationPath: destPath,
          captureDate: metadata.captureDate.toISOString(),
          status: 'skipped',
          duplicateInfo: copyResult.reason
        });
      }
    } catch (error) {
      const errorMsg = String(error);
      this.state.errors.push(errorMsg);
      this.manifest.push({
        sourcePath: photoPath,
        destinationPath: '',
        captureDate: 'unknown',
        status: 'error',
        error: errorMsg
      });
      await logger.error('Failed to process photo', { photoPath, error: errorMsg });
    }
  }

  private buildResult(): OrganizationResult {
    const yearsCreated = new Set<string>();

    for (const entry of this.manifest) {
      if (entry.status === 'copied') {
        const match = entry.destinationPath.match(/(\d{4})/);
        if (match) {
          yearsCreated.add(match[1]);
        }
      }
    }

    return {
      totalPhotos: this.state.totalFiles,
      yearsCreated: Array.from(yearsCreated).sort(),
      monthsCreated: new Set(
        this.manifest
          .filter(e => e.status === 'copied')
          .map(e => e.destinationPath)
          .filter(p => p.includes('/'))
      ).size,
      filesCopied: this.state.filesCopied,
      duplicateNamesFound: this.state.duplicatesFound,
      errors: this.state.errors,
      skippedFiles: this.state.filesSkipped,
      duplicateReport: this.duplicates,
      manifest: this.manifest
    };
  }

  getDuplicates(): DuplicateEntry[] {
    return this.duplicates;
  }

  getManifest(): ManifestEntry[] {
    return this.manifest;
  }
}

export const organizerService = new OrganizerService();
