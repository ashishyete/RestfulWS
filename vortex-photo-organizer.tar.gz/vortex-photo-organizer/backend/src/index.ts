import express, { Request, Response } from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { logger } from './utils/logger.js';
import { organizerService } from './services/organizerService.js';
import { OrganizationState } from './types.js';
import fs from 'fs/promises';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4001;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize
async function initialize() {
  await logger.initialize();
  await logger.info('Server starting', { port: PORT });
}

initialize().catch(console.error);

// API Routes

/**
 * GET /api/health - Health check
 */
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

/**
 * POST /api/scan - Scan source directory for photos
 */
app.post('/api/scan', async (req: Request, res: Response) => {
  try {
    const { sourceDir, dryRun = false } = req.body;

    if (!sourceDir) {
      return res.status(400).json({ error: 'sourceDir is required' });
    }

    const result = await organizerService.scan(sourceDir, dryRun);

    if (result.error) {
      return res.status(400).json({ error: result.error });
    }

    res.json({
      message: 'Scan completed',
      photoCount: result.count,
      state: organizerService.getState()
    });
  } catch (error) {
    await logger.error('Scan endpoint error', error);
    res.status(500).json({ error: 'Failed to scan directory' });
  }
});

/**
 * POST /api/organize - Start photo organization
 */
app.post('/api/organize', async (req: Request, res: Response) => {
  try {
    const { sourceDir, destDir, dryRun = false } = req.body;

    if (!sourceDir || !destDir) {
      return res.status(400).json({ error: 'sourceDir and destDir are required' });
    }

    const result = await organizerService.organize(sourceDir, destDir, dryRun);

    res.json({
      message: 'Organization completed',
      result,
      state: organizerService.getState()
    });
  } catch (error) {
    await logger.error('Organize endpoint error', error);
    res.status(500).json({ error: 'Failed to organize photos' });
  }
});

/**
 * GET /api/progress - Get current organization progress
 */
app.get('/api/progress', (req: Request, res: Response) => {
  try {
    const state = organizerService.getState();
    res.json(state);
  } catch (error) {
    await logger.error('Progress endpoint error', error);
    res.status(500).json({ error: 'Failed to get progress' });
  }
});

/**
 * GET /api/logs - Get recent logs
 */
app.get('/api/logs', async (req: Request, res: Response) => {
  try {
    const lines = req.query.lines ? parseInt(req.query.lines as string) : 100;
    const logs = await logger.getLogs(lines);
    res.json({ logs });
  } catch (error) {
    await logger.error('Logs endpoint error', error);
    res.status(500).json({ error: 'Failed to get logs' });
  }
});

/**
 * GET /api/duplicates - Get duplicate detection report
 */
app.get('/api/duplicates', (req: Request, res: Response) => {
  try {
    const duplicates = organizerService.getDuplicates();
    res.json({
      count: duplicates.length,
      duplicates
    });
  } catch (error) {
    await logger.error('Duplicates endpoint error', error);
    res.status(500).json({ error: 'Failed to get duplicates' });
  }
});

/**
 * GET /api/manifest - Get manifest of all processed files
 */
app.get('/api/manifest', (req: Request, res: Response) => {
  try {
    const manifest = organizerService.getManifest();
    res.json({
      count: manifest.length,
      manifest
    });
  } catch (error) {
    await logger.error('Manifest endpoint error', error);
    res.status(500).json({ error: 'Failed to get manifest' });
  }
});

/**
 * POST /api/logs/clear - Clear all logs
 */
app.post('/api/logs/clear', async (req: Request, res: Response) => {
  try {
    await logger.clearLogs();
    res.json({ message: 'Logs cleared' });
  } catch (error) {
    await logger.error('Clear logs endpoint error', error);
    res.status(500).json({ error: 'Failed to clear logs' });
  }
});

/**
 * GET /api/export/duplicates - Export duplicate report as CSV
 */
app.get('/api/export/duplicates', (req: Request, res: Response) => {
  try {
    const duplicates = organizerService.getDuplicates();

    let csv = 'Filename,Destination,Source File,Source Directory\n';
    for (const dup of duplicates) {
      const row = [dup.filename, dup.destination, dup.sourceFile, dup.sourceDir]
        .map(field => `"${field.replace(/"/g, '""')}"`)
        .join(',');
      csv += row + '\n';
    }

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="duplicate-report.csv"');
    res.send(csv);
  } catch (error) {
    await logger.error('Export duplicates endpoint error', error);
    res.status(500).json({ error: 'Failed to export duplicates' });
  }
});

/**
 * GET /api/export/manifest - Export manifest as CSV
 */
app.get('/api/export/manifest', (req: Request, res: Response) => {
  try {
    const manifest = organizerService.getManifest();

    let csv = 'Source Path,Destination Path,Capture Date,Status,Notes\n';
    for (const entry of manifest) {
      const notes = entry.error || entry.duplicateInfo || '';
      const row = [entry.sourcePath, entry.destinationPath, entry.captureDate, entry.status, notes]
        .map(field => `"${field.replace(/"/g, '""')}"`)
        .join(',');
      csv += row + '\n';
    }

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="manifest.csv"');
    res.send(csv);
  } catch (error) {
    await logger.error('Export manifest endpoint error', error);
    res.status(500).json({ error: 'Failed to export manifest' });
  }
});

/**
 * Serve static frontend files (when built)
 */
const distPath = path.join(__dirname, '../../frontend/dist');
app.use(express.static(distPath));

/**
 * Fallback to index.html for SPA routing
 */
app.get('*', (req: Request, res: Response) => {
  const indexPath = path.join(distPath, 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      res.status(404).json({ error: 'Not found' });
    }
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`\n🌀 Vortex Photo Organizer running on http://localhost:${PORT}\n`);
  logger.info(`Server started on port ${PORT}`);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\nShutting down gracefully...');
  await logger.info('Server shutdown');
  process.exit(0);
});
