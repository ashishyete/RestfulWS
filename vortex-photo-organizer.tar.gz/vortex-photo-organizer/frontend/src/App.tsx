import { useState, useEffect } from 'react';
import './styles/index.css';
import { apiService } from './services/api';
import { OrganizationState, OrganizationResult } from './types/index';
import OrganizationForm from './components/OrganizationForm';
import ProgressPanel from './components/ProgressPanel';
import ResultsPanel from './components/ResultsPanel';
import LogsPanel from './components/LogsPanel';

function App() {
  const [sourceDir, setSourceDir] = useState('');
  const [destDir, setDestDir] = useState('');
  const [dryRun, setDryRun] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [state, setState] = useState<OrganizationState | null>(null);
  const [result, setResult] = useState<OrganizationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showLogs, setShowLogs] = useState(false);

  // Poll for progress updates
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isLoading) {
      interval = setInterval(async () => {
        try {
          const progress = await apiService.getProgress();
          setState(progress);

          if (progress.status === 'completed' || progress.status === 'error') {
            setIsLoading(false);
          }
        } catch (err) {
          console.error('Failed to get progress:', err);
        }
      }, 500);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLoading]);

  const handleScan = async () => {
    if (!sourceDir.trim()) {
      setError('Please enter a source directory');
      return;
    }

    setError(null);
    setIsLoading(true);

    try {
      const { photoCount } = await apiService.scan(sourceDir, dryRun);
      setState({
        status: 'scanning',
        sourceDir,
        destDir,
        progress: 0,
        currentFile: '',
        currentYear: '',
        currentMonth: '',
        filesCopied: 0,
        filesSkipped: 0,
        duplicatesFound: 0,
        errors: [],
        startTime: null,
        estimatedTimeRemaining: null,
        elapsedTime: 0,
        totalFiles: photoCount,
        dryRun
      });
      setIsLoading(false);
      setError(`Found ${photoCount} photos`);
    } catch (err) {
      setError(`Scan failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
      setIsLoading(false);
    }
  };

  const handleOrganize = async () => {
    if (!sourceDir.trim() || !destDir.trim()) {
      setError('Please enter both source and destination directories');
      return;
    }

    setError(null);
    setResult(null);
    setIsLoading(true);

    try {
      const { result: orgResult, state: orgState } = await apiService.organize(
        sourceDir,
        destDir,
        dryRun
      );
      setState(orgState);
      setResult(orgResult);
      setIsLoading(false);
    } catch (err) {
      setError(`Organization failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setIsLoading(false);
    setError(null);
  };

  return (
    <div className="container">
      <div className="header">
        <h1>🌀 Vortex Photo Organizer</h1>
        <p>Organize your photos into a clean Year/Month folder hierarchy</p>
      </div>

      <div className="main">
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          {error && (
            <div className={`alert ${error.includes('failed') || error.includes('Error') ? 'alert-error' : error.includes('Found') ? 'alert-success' : 'alert-warning'}`}>
              {error}
            </div>
          )}

          <OrganizationForm
            sourceDir={sourceDir}
            destDir={destDir}
            dryRun={dryRun}
            isLoading={isLoading}
            onSourceDirChange={setSourceDir}
            onDestDirChange={setDestDir}
            onDryRunChange={setDryRun}
            onScan={handleScan}
            onOrganize={handleOrganize}
            onCancel={handleCancel}
          />

          {state && (
            <>
              <ProgressPanel state={state} />

              <div style={{ marginTop: '20px' }}>
                <button
                  onClick={() => setShowLogs(!showLogs)}
                  className="btn-secondary"
                >
                  {showLogs ? 'Hide Logs' : 'Show Logs'}
                </button>
              </div>

              {showLogs && <LogsPanel />}
            </>
          )}

          {result && (
            <ResultsPanel result={result} />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
