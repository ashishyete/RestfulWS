import { OrganizationState, OrganizationResult, DuplicateEntry } from '../types/index';

const API_BASE = '/api';

export const apiService = {
  async scan(sourceDir: string, dryRun: boolean = false): Promise<{ photoCount: number; state: OrganizationState }> {
    const response = await fetch(`${API_BASE}/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sourceDir, dryRun })
    });

    if (!response.ok) throw new Error('Failed to scan directory');
    return response.json();
  },

  async organize(sourceDir: string, destDir: string, dryRun: boolean = false): Promise<{ result: OrganizationResult; state: OrganizationState }> {
    const response = await fetch(`${API_BASE}/organize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sourceDir, destDir, dryRun })
    });

    if (!response.ok) throw new Error('Failed to organize photos');
    return response.json();
  },

  async getProgress(): Promise<OrganizationState> {
    const response = await fetch(`${API_BASE}/progress`);
    if (!response.ok) throw new Error('Failed to get progress');
    return response.json();
  },

  async getLogs(lines: number = 100): Promise<string> {
    const response = await fetch(`${API_BASE}/logs?lines=${lines}`);
    if (!response.ok) throw new Error('Failed to get logs');
    const data = await response.json();
    return data.logs;
  },

  async getDuplicates(): Promise<{ count: number; duplicates: DuplicateEntry[] }> {
    const response = await fetch(`${API_BASE}/duplicates`);
    if (!response.ok) throw new Error('Failed to get duplicates');
    return response.json();
  },

  async clearLogs(): Promise<void> {
    const response = await fetch(`${API_BASE}/logs/clear`, { method: 'POST' });
    if (!response.ok) throw new Error('Failed to clear logs');
  },

  async exportDuplicates(): Promise<void> {
    const response = await fetch(`${API_BASE}/export/duplicates`);
    if (!response.ok) throw new Error('Failed to export duplicates');

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'duplicate-report.csv';
    a.click();
  },

  async exportManifest(): Promise<void> {
    const response = await fetch(`${API_BASE}/export/manifest`);
    if (!response.ok) throw new Error('Failed to export manifest');

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'manifest.csv';
    a.click();
  }
};
