import { OrganizationState } from '../types/index';

interface ProgressPanelProps {
  state: OrganizationState;
}

function formatTime(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}m ${secs}s`;
}

export default function ProgressPanel({ state }: ProgressPanelProps) {
  const statusLabel = {
    idle: 'Idle',
    scanning: 'Scanning...',
    organizing: 'Organizing...',
    completed: 'Completed',
    error: 'Error'
  }[state.status];

  const statusClass = `status status-${state.status}`;

  return (
    <div className="card" style={{ marginBottom: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>Progress</h2>
        <div className={statusClass}>{statusLabel}</div>
      </div>

      {state.status !== 'idle' && (
        <>
          <div className="progress-bar">
            <div
              className="progress-fill"
              style={{ width: `${state.progress}%` }}
            />
          </div>

          <div style={{ textAlign: 'center', marginBottom: '16px', fontSize: '14px', color: 'var(--gray-600)' }}>
            {state.progress}% • {state.filesCopied + state.filesSkipped} / {state.totalFiles} files
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '20px' }}>
            <div style={{ padding: '12px', backgroundColor: 'var(--gray-50)', borderRadius: '6px' }}>
              <div style={{ fontSize: '12px', color: 'var(--gray-600)', marginBottom: '4px' }}>Current File</div>
              <div style={{ fontSize: '13px', fontWeight: '500', wordBreak: 'break-all' }}>
                {state.currentFile || 'N/A'}
              </div>
            </div>

            <div style={{ padding: '12px', backgroundColor: 'var(--gray-50)', borderRadius: '6px' }}>
              <div style={{ fontSize: '12px', color: 'var(--gray-600)', marginBottom: '4px' }}>Current Year/Month</div>
              <div style={{ fontSize: '13px', fontWeight: '500' }}>
                {state.currentYear ? `${state.currentYear}/${state.currentMonth}` : 'N/A'}
              </div>
            </div>
          </div>

          <div className="stat-row">
            <span className="stat-label">Files Copied</span>
            <span className="stat-value">{state.filesCopied}</span>
          </div>

          <div className="stat-row">
            <span className="stat-label">Files Skipped</span>
            <span className="stat-value">{state.filesSkipped}</span>
          </div>

          <div className="stat-row">
            <span className="stat-label">Duplicates Found</span>
            <span className="stat-value">{state.duplicatesFound}</span>
          </div>

          <div className="stat-row">
            <span className="stat-label">Elapsed Time</span>
            <span className="stat-value">{formatTime(state.elapsedTime)}</span>
          </div>

          {state.estimatedTimeRemaining && state.status === 'organizing' && (
            <div className="stat-row">
              <span className="stat-label">Estimated Time Remaining</span>
              <span className="stat-value">{formatTime(state.estimatedTimeRemaining)}</span>
            </div>
          )}

          {state.errors.length > 0 && (
            <div style={{ marginTop: '16px', padding: '12px', backgroundColor: '#fee2e2', borderRadius: '6px', borderLeft: '4px solid var(--error)' }}>
              <div style={{ fontSize: '12px', fontWeight: '600', color: '#991b1b', marginBottom: '8px' }}>
                Errors ({state.errors.length})
              </div>
              <div style={{ fontSize: '12px', color: '#7f1d1d', maxHeight: '120px', overflowY: 'auto' }}>
                {state.errors.map((error, i) => (
                  <div key={i} style={{ marginBottom: '4px' }}>• {error}</div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
