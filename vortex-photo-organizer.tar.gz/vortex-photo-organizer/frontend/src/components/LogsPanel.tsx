import { useState, useEffect } from 'react';
import { apiService } from '../services/api';

export default function LogsPanel() {
  const [logs, setLogs] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const logsContent = await apiService.getLogs(200);
        setLogs(logsContent);
      } catch (err) {
        setLogs('Failed to load logs');
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();
    const interval = setInterval(fetchLogs, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleClear = async () => {
    if (confirm('Clear all logs?')) {
      try {
        await apiService.clearLogs();
        setLogs('');
      } catch (err) {
        alert('Failed to clear logs');
      }
    }
  };

  return (
    <div className="card" style={{ marginTop: '20px', marginBottom: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>Logs</h2>
        <button onClick={handleClear} className="btn-secondary" style={{ padding: '6px 12px', fontSize: '12px' }}>
          Clear
        </button>
      </div>

      {loading ? (
        <div className="center" style={{ padding: '20px' }}>
          <span className="spinner" />
          Loading logs...
        </div>
      ) : (
        <div className="logs-container">
          {logs}
        </div>
      )}
    </div>
  );
}
