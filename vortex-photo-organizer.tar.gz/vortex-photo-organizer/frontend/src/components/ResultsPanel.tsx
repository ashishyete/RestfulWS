import { OrganizationResult } from '../types/index';
import { apiService } from '../services/api';

interface ResultsPanelProps {
  result: OrganizationResult;
}

export default function ResultsPanel({ result }: ResultsPanelProps) {
  const handleExportDuplicates = async () => {
    try {
      await apiService.exportDuplicates();
    } catch (err) {
      alert(`Failed to export duplicates: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const handleExportManifest = async () => {
    try {
      await apiService.exportManifest();
    } catch (err) {
      alert(`Failed to export manifest: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  return (
    <div className="card">
      <h2 style={{ marginBottom: '20px', fontSize: '18px', fontWeight: '600' }}>
        ✅ Organization Results
      </h2>

      <div className="results-grid">
        <div className="result-card">
          <div className="result-label">Total Photos</div>
          <div className="result-value">{result.totalPhotos}</div>
        </div>

        <div className="result-card">
          <div className="result-label">Files Copied</div>
          <div className="result-value">{result.filesCopied}</div>
        </div>

        <div className="result-card">
          <div className="result-label">Years Created</div>
          <div className="result-value">{result.yearsCreated.length}</div>
        </div>

        <div className="result-card">
          <div className="result-label">Months Created</div>
          <div className="result-value">{result.monthsCreated}</div>
        </div>

        <div className="result-card">
          <div className="result-label">Files Skipped</div>
          <div className="result-value">{result.skippedFiles}</div>
        </div>

        <div className="result-card">
          <div className="result-label">Duplicates Found</div>
          <div className="result-value">{result.duplicateNamesFound}</div>
        </div>
      </div>

      {result.yearsCreated.length > 0 && (
        <div style={{ marginTop: '20px', padding: '12px', backgroundColor: 'var(--gray-50)', borderRadius: '6px' }}>
          <div style={{ fontSize: '12px', fontWeight: '600', color: 'var(--gray-700)', marginBottom: '8px' }}>
            Years Created
          </div>
          <div style={{ fontSize: '14px', color: 'var(--gray-900)' }}>
            {result.yearsCreated.join(', ')}
          </div>
        </div>
      )}

      {result.errors.length > 0 && (
        <div style={{ marginTop: '20px', padding: '12px', backgroundColor: '#fee2e2', borderRadius: '6px', borderLeft: '4px solid var(--error)' }}>
          <div style={{ fontSize: '12px', fontWeight: '600', color: '#991b1b', marginBottom: '8px' }}>
            Errors ({result.errors.length})
          </div>
          <div style={{ fontSize: '12px', color: '#7f1d1d', maxHeight: '150px', overflowY: 'auto' }}>
            {result.errors.map((error, i) => (
              <div key={i} style={{ marginBottom: '4px' }}>• {error}</div>
            ))}
          </div>
        </div>
      )}

      <div className="button-group" style={{ marginTop: '20px' }}>
        <button onClick={handleExportDuplicates} className="btn-secondary">
          📋 Export Duplicates Report
        </button>
        <button onClick={handleExportManifest} className="btn-secondary">
          📊 Export Manifest
        </button>
      </div>
    </div>
  );
}
