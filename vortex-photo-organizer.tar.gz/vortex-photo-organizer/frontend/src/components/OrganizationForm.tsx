interface OrganizationFormProps {
  sourceDir: string;
  destDir: string;
  dryRun: boolean;
  isLoading: boolean;
  onSourceDirChange: (dir: string) => void;
  onDestDirChange: (dir: string) => void;
  onDryRunChange: (dryRun: boolean) => void;
  onScan: () => void;
  onOrganize: () => void;
  onCancel: () => void;
}

export default function OrganizationForm({
  sourceDir,
  destDir,
  dryRun,
  isLoading,
  onSourceDirChange,
  onDestDirChange,
  onDryRunChange,
  onScan,
  onOrganize,
  onCancel
}: OrganizationFormProps) {
  return (
    <div className="card" style={{ marginBottom: '20px' }}>
      <h2 style={{ marginBottom: '20px', fontSize: '18px', fontWeight: '600' }}>
        Configure Organization
      </h2>

      <div className="form-group">
        <label htmlFor="sourceDir">Source Directory</label>
        <input
          id="sourceDir"
          type="text"
          placeholder="/Users/me/Pictures/Camera"
          value={sourceDir}
          onChange={(e) => onSourceDirChange(e.target.value)}
          disabled={isLoading}
        />
        <p className="info-text">
          Directory containing your photos
        </p>
      </div>

      <div className="form-group">
        <label htmlFor="destDir">Destination Directory</label>
        <input
          id="destDir"
          type="text"
          placeholder="/Users/me/PhotoLibrary"
          value={destDir}
          onChange={(e) => onDestDirChange(e.target.value)}
          disabled={isLoading}
        />
        <p className="info-text">
          Where organized photos will be copied (original files never touched)
        </p>
      </div>

      <div className="form-group">
        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={dryRun}
            onChange={(e) => onDryRunChange(e.target.checked)}
            disabled={isLoading}
            style={{ width: 'auto' }}
          />
          <span>Dry Run (preview without copying)</span>
        </label>
        <p className="info-text">
          Preview exactly what will happen without actually copying files
        </p>
      </div>

      <div className="button-group">
        <button
          onClick={onScan}
          disabled={isLoading || !sourceDir.trim()}
          className="btn-secondary"
        >
          {isLoading ? '⏳ Processing...' : 'Scan'}
        </button>
        <button
          onClick={onOrganize}
          disabled={isLoading || !sourceDir.trim() || !destDir.trim()}
          className="btn-primary"
        >
          {isLoading ? '⏳ Organizing...' : 'Organize'}
        </button>
        {isLoading && (
          <button onClick={onCancel} className="btn-secondary">
            Cancel
          </button>
        )}
      </div>
    </div>
  );
}
