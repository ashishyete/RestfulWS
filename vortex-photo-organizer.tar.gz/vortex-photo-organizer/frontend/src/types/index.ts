export interface OrganizationState {
  status: 'idle' | 'scanning' | 'organizing' | 'completed' | 'error';
  sourceDir: string;
  destDir: string;
  progress: number;
  currentFile: string;
  currentYear: string;
  currentMonth: string;
  filesCopied: number;
  filesSkipped: number;
  duplicatesFound: number;
  errors: string[];
  startTime: number | null;
  estimatedTimeRemaining: number | null;
  elapsedTime: number;
  totalFiles: number;
  dryRun: boolean;
}

export interface OrganizationResult {
  totalPhotos: number;
  yearsCreated: string[];
  monthsCreated: number;
  filesCopied: number;
  duplicateNamesFound: number;
  errors: string[];
  skippedFiles: number;
}

export interface DuplicateEntry {
  filename: string;
  destination: string;
  sourceFile: string;
  sourceDir: string;
}
