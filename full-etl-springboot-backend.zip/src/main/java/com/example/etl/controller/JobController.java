package com.example.etl.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/jobs")
public class JobController {

    @PostMapping("/{id}/run")
    public String runJob(@PathVariable String id) {
        return "Triggered job: " + id;
    }

    @PutMapping("/{id}/schedule")
    public String updateJobSchedule(@PathVariable String id, @RequestBody String cron) {
        return "Updated schedule for job: " + id + " to " + cron;
    }

    @GetMapping("")
    public String listJobs() {
        return "List of jobs";
    }
}
